use craft_audio::{AudioBuffer, BitDepth, EncodeOptions};
use serde_json::{Value, json};
use soundcraft_engine::{Engine, file_access};
use soundcraft_model::{ChannelFormat, Session, TrackKind};
use soundcraft_time::SampleRate;
use std::{
    io::{Cursor, Read},
    path::PathBuf,
    sync::atomic::{AtomicU64, Ordering},
};

struct Fixture {
    dir: PathBuf,
    params: Value,
}
impl Fixture {
    fn new() -> Self {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let dir = std::env::temp_dir().join(format!("soundcraft-aaf-{}-{}", std::process::id(), NEXT.fetch_add(1, Ordering::Relaxed)));
        std::fs::create_dir(&dir).unwrap();
        let path = dir.join("Source á with spaces.wav");
        let mut ch = vec![0.0; 480000];
        ch[96000] = 0.5;
        let bytes = craft_audio::encode(
            &AudioBuffer { sample_rate: 48000, channels: vec![ch] },
            &EncodeOptions::new(craft_audio::EncodeFormat::Wav).with_bit_depth(BitDepth::Int16),
        )
        .unwrap();
        std::fs::write(&path, bytes).unwrap();
        let params = json!({"plan":{"schema_version":1,"name":"AAF test","sample_rate":48000,"timecode_start":[3600,1],"frame_rate":{"rate":[25,1],"drop":false},"warnings":["Test warning"],
            "sources":[{"key":"source","name":"Original source","path":std::fs::canonicalize(&path).unwrap(),"channels":1,"frames":480000,"sample_rate":48000}],
            "tracks":[{"name":"DX","channels":1,"clips":[{"name":"Cut","source":"source","start":[1,1],"end":[3,1],"offset":[2,1]}]},
                      {"name":"Empty","channels":1,"clips":[]}]},"media_dir":dir,"selected":[0],"mapping":"absolute","media":"copy","offset_samples":0});
        Self { dir, params }
    }
}
impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.dir);
    }
}
fn existing() -> Engine {
    let mut s = Session::new("Existing", SampleRate::HZ_48000);
    s.add_track(TrackKind::Audio, ChannelFormat::Mono, Some("Keep"));
    Engine::new(s)
}
#[test]
fn absolute_mapping_preserves_source_window_and_is_one_undo_step() {
    let f = Fixture::new();
    let mut e = existing();
    let before = e.session().to_json().unwrap();
    let report = e.execute("file.import_aaf", &f.params).unwrap();
    assert_eq!(report["tracks"].as_array().unwrap().len(), 1);
    assert_eq!(e.session().tracks.len(), 2);
    let c = &e.session().tracks[1].clips()[0];
    assert_eq!((c.start, c.length, c.source_offset()), (172848000, 96000, 96000));
    assert_eq!(e.session().sources[0].frames, 480000);
    assert!(e.session().sources[0].unsaved);
    let source = c.source().unwrap();
    assert_eq!(e.session().pool.get(source).unwrap().channel(0).unwrap()[96000], 0.5);
    assert_eq!(e.undo_label(), Some("Session Data (AAF)..."));
    e.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(e.session().to_json().unwrap(), before);
}
#[test]
fn relative_mapping_and_track_selection_do_not_replace_existing_tracks() {
    let mut f = Fixture::new();
    let mut e = existing();
    f.params["mapping"] = json!("relative");
    f.params["offset_samples"] = json!(96000);
    e.execute("file.import_aaf", &f.params).unwrap();
    assert_eq!(e.session().tracks[0].name, "Keep");
    assert_eq!(e.session().tracks[1].name, "DX");
    assert_eq!(e.session().tracks[1].clips()[0].start, 144000);
    assert!(e.session().sources[0].unsaved);
}
#[test]
fn empty_session_adopts_source_clock_and_save_collects_the_whole_source() {
    let f = Fixture::new();
    let mut e = Engine::default();
    e.execute("file.import_aaf", &f.params).unwrap();
    assert_eq!(e.session().timecode_start, 172800000);
    assert_eq!(e.session().tracks[0].clips()[0].start, 48000);
    let dest = f.dir.join("Saved/session.scraft");
    soundcraft_engine::io::save_session(&mut e, &dest.to_string_lossy()).unwrap();
    let file = f.dir.join("Saved").join(&e.session().sources[0].path);
    let info = craft_audio::probe(&std::fs::read(file).unwrap(), Some("wav")).unwrap();
    assert_eq!(info.frames, 480000);
    assert_eq!(e.session().tracks[0].clips()[0].source_offset(), 96000);
}
#[test]
fn invalid_inputs_fail_without_mutation() {
    let f = Fixture::new();
    let mut e = existing();
    let before = e.session().to_json().unwrap();
    for update in [
        json!({"selected":[]}),
        json!({"selected":[99]}),
        json!({"selected":[0,0]}),
        json!({"mapping":"unknown"}),
        json!({"media":"link"}),
        json!({"offset_samples":-172900000}),
    ] {
        let mut p = f.params.clone();
        for (k, v) in update.as_object().unwrap() {
            p[k] = v.clone();
        }
        assert!(e.execute("file.import_aaf", &p).is_err());
        assert_eq!(e.session().to_json().unwrap(), before);
        assert!(e.undo_label().is_none());
    }
    std::fs::remove_file(f.dir.join("Source á with spaces.wav")).unwrap();
    assert!(e.execute("file.import_aaf", &f.params).is_err());
    assert_eq!(e.session().to_json().unwrap(), before);
}
#[test]
fn sample_rate_changes_and_confined_media_are_rejected() {
    let f = Fixture::new();
    let mut s = Session::new("44.1", SampleRate::HZ_44100);
    s.add_track(TrackKind::Audio, ChannelFormat::Mono, Some("Existing"));
    let mut e = Engine::new(s);
    assert!(e.execute("file.import_aaf", &f.params).unwrap_err().to_string().contains("sample rates differ"));
    let restricted = f.dir.join("allowed");
    std::fs::create_dir(&restricted).unwrap();
    let roots = file_access::AutomationRoots::new(&[restricted.as_path()], &[]).unwrap();
    let mut e = existing();
    assert!(file_access::confine(roots.as_ref(), || e.execute("file.import_aaf", &f.params)).is_err());
    assert_eq!(e.session().tracks.len(), 1);
}
#[test]
fn import_confines_the_plans_media_to_the_media_folder_again() {
    // A plan is caller-supplied (MCP, automation): editing its paths must not reach other files.
    let f = Fixture::new();
    let mut e = existing();
    let before = e.session().to_json().unwrap();
    let elsewhere = f.dir.join("elsewhere");
    std::fs::create_dir(&elsewhere).unwrap();
    std::fs::copy(f.dir.join("Source á with spaces.wav"), elsewhere.join("Source á with spaces.wav")).unwrap();
    let outside = std::fs::canonicalize(elsewhere.join("Source á with spaces.wav")).unwrap();
    let traversal = elsewhere.join("..").join("elsewhere").join("Source á with spaces.wav");
    for path in [json!(outside), json!(traversal)] {
        let mut p = f.params.clone();
        p["plan"]["sources"][0]["path"] = path.clone();
        let err = e.execute("file.import_aaf", &p).unwrap_err().to_string();
        assert!(err.contains("outside the media folder"), "{path}: {err}");
    }
    #[cfg(unix)]
    {
        let link = f.dir.join("link.wav");
        std::os::unix::fs::symlink(&outside, &link).unwrap();
        let mut p = f.params.clone();
        p["plan"]["sources"][0]["path"] = json!(link);
        assert!(e.execute("file.import_aaf", &p).unwrap_err().to_string().contains("outside the media folder"));
    }
    let mut p = f.params.clone();
    p.as_object_mut().unwrap().remove("media_dir");
    assert!(e.execute("file.import_aaf", &p).unwrap_err().to_string().contains("media_dir"));
    assert_eq!(e.session().to_json().unwrap(), before);
    assert!(e.undo_label().is_none());
}
#[test]
fn playing_import_cannot_bypass_the_transport_guard_with_target_params() {
    let f = Fixture::new();
    let mut e = existing();
    e.transport.playing = true;
    let mut p = f.params.clone();
    p["tracks"] = json!([1]);
    assert!(e.execute("file.import_aaf", &p).is_err());
    assert_eq!(e.session().tracks.len(), 1);
}

/// A synthetic AAF (two tracks, three edits, chained source offsets) written by pyaaf2. Its
/// external WAVs are regenerated here with the same names, layouts and lengths.
struct AafFolder {
    dir: PathBuf,
}
impl AafFolder {
    fn new() -> Self {
        let dir = Fixture::new().dir.with_extension("aaf");
        std::fs::create_dir(&dir).unwrap();
        std::fs::copy(concat!(env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/synthetic-two-tracks.aaf"), dir.join("Montaje sintético.aaf")).unwrap();
        for (name, channels) in [("Diálogo á #1.wav", 1), ("Ambiente estéreo.wav", 2)] {
            let audio = AudioBuffer { sample_rate: 48000, channels: vec![vec![0.25; 384000]; channels] };
            let options = EncodeOptions::new(craft_audio::EncodeFormat::Wav).with_bit_depth(BitDepth::Int16);
            std::fs::write(dir.join(name), craft_audio::encode(&audio, &options).unwrap()).unwrap();
        }
        Self { dir }
    }
    fn preview(&self) -> soundcraft_engine::Result<Value> {
        let aaf = self.dir.join("Montaje sintético.aaf");
        Engine::default().execute("file.preview_aaf", &json!({"path": aaf, "media_dir": self.dir}))
    }
}
impl Drop for AafFolder {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.dir);
    }
}

#[test]
fn rust_reader_turns_an_aaf_file_into_editable_tracks() {
    let f = AafFolder::new();
    let preview = f.preview().unwrap();
    let plan = &preview["plan"];
    assert_eq!(plan["name"], "Clase AAF — cortes y handles");
    assert_eq!(plan["timecode_start"], json!([3600, 1]));
    assert_eq!(plan["frame_rate"], json!({"rate": [25, 1], "drop": false}));
    let names: Vec<_> = plan["tracks"].as_array().unwrap().iter().map(|t| t["name"].as_str().unwrap()).collect();
    assert_eq!(names, ["01 Diálogo", "02 Ambiente estéreo"]);
    assert_eq!(plan["tracks"][0]["clips"][1]["offset"], json!([7, 2]));
    let channels: Vec<_> = plan["sources"].as_array().unwrap().iter().map(|s| s["channels"].as_u64().unwrap()).collect();
    assert_eq!(channels, [1, 2]);
    assert!(plan["sources"][0]["path"].as_str().unwrap().ends_with("Diálogo á #1.wav"));

    let mut e = Engine::default();
    e.execute("file.import_aaf", &json!({"plan": plan, "media_dir": f.dir, "selected": [0, 1]})).unwrap();
    let edits: Vec<_> = e.session().tracks.iter().flat_map(|t| t.clips()).map(|c| (c.start, c.length, c.source_offset())).collect();
    assert_eq!(edits, [(48000, 96000, 48000), (192000, 48000, 168000), (0, 240000, 72000)]);
    assert_eq!(e.session().timecode_start, 3600 * 48000);
    assert_eq!(e.session().tracks[1].channels(), 2);
}

#[test]
fn missing_media_is_reported_and_its_edits_skipped_without_failing_the_import() {
    let f = AafFolder::new();
    std::fs::remove_file(f.dir.join("Diálogo á #1.wav")).unwrap();
    let preview = f.preview().unwrap();
    let plan = &preview["plan"];
    let missing: Vec<_> = plan["warnings"].as_array().unwrap().iter().filter_map(|w| w.as_str()).filter(|w| w.starts_with("Missing media")).collect();
    assert_eq!(missing.len(), 1, "{missing:?}");
    assert!(missing[0].contains("Diálogo á #1.wav") && missing[0].contains("2 edit(s) skipped"), "{}", missing[0]);
    // The dialogue track keeps its name but loses its two edits; the ambience edit is intact.
    assert_eq!(plan["tracks"][0]["clips"].as_array().unwrap().len(), 0);
    assert_eq!(plan["tracks"][1]["clips"].as_array().unwrap().len(), 1);
    assert_eq!(plan["sources"].as_array().unwrap().len(), 1);
    let mut e = Engine::default();
    e.execute("file.import_aaf", &json!({"plan": plan, "media_dir": f.dir, "selected": [0, 1]})).unwrap();
    let edits: Vec<_> = e.session().tracks.iter().flat_map(|t| t.clips()).map(|c| (c.start, c.length, c.source_offset())).collect();
    assert_eq!(edits, [(0, 240000, 72000)]);

    // With no media at all there is nothing to import.
    std::fs::remove_file(f.dir.join("Ambiente estéreo.wav")).unwrap();
    let err = f.preview().unwrap_err().to_string();
    assert!(err.contains("none of the referenced files were found"), "{err}");
}

#[test]
fn media_that_is_present_but_not_a_wav_still_fails() {
    let f = AafFolder::new();
    std::fs::write(f.dir.join("Diálogo á #1.wav"), b"RIFF\0\0\0\0WAVEnot audio").unwrap();
    assert!(f.preview().is_err());
}

/// The fixture with its first WAV locator (`Di%C3%A1logo%20%C3%A1%20%231.wav`, 32 UTF-16 units)
/// replaced by `url`, padded to the same length so the property stream stays well formed.
fn with_locator(f: &AafFolder, url: &str) -> soundcraft_engine::Result<Value> {
    let original = "Di%C3%A1logo%20%C3%A1%20%231.wav";
    assert_eq!(url.encode_utf16().count(), original.encode_utf16().count(), "{url}");
    let aaf = f.dir.join("Montaje sintético.aaf");
    let mut bytes = std::fs::read(&aaf).unwrap();
    let from: Vec<u8> = original.encode_utf16().flat_map(u16::to_le_bytes).collect();
    let to: Vec<u8> = url.encode_utf16().flat_map(u16::to_le_bytes).collect();
    let at = bytes.windows(from.len()).position(|w| w == from.as_slice()).unwrap();
    bytes[at..at + to.len()].copy_from_slice(&to);
    std::fs::write(&aaf, bytes).unwrap();
    f.preview()
}

#[test]
fn locators_that_try_to_leave_the_aaf_folder_are_refused() {
    for url in [
        "../../../../../../etc/passwd.wav",
        "%2E%2E/%2E%2E/%2E%2E/secret1.wav",
        "file:///tmp/../etc/shadow000.wav",
        "http://evil.example/payload0.wav",
        "file://server/share/payload0.wav",
        "Di%C3%A1logo%20%C3%A1%20%231.wa/",
        "Di%C3%A1logo%20%C3%A1%20%001.wav",
    ] {
        let f = AafFolder::new();
        let err = with_locator(&f, url).unwrap_err().to_string();
        assert!(err.contains("ocator"), "{url}: {err}");
    }
}

#[test]
fn an_absolute_locator_only_names_a_file_in_the_chosen_media_folder() {
    // A locator pointing anywhere on disk is reduced to its file name and looked up only in the
    // media folder the user chose: the real file elsewhere is never opened.
    let f = AafFolder::new();
    let preview = with_locator(&f, "file:///etc/Dlogo%20%C3%A1_1.wav").unwrap();
    let w: Vec<_> = preview["plan"]["warnings"].as_array().unwrap().iter().filter_map(|w| w.as_str()).collect();
    assert!(
        w.iter().any(
            |w| w.starts_with("Missing media") && w.contains(&std::fs::canonicalize(&f.dir).unwrap().join("Dlogo á_1.wav").display().to_string())
        ),
        "{w:?}"
    );
}

/// Offsets into a structured-storage (CFB) file, enough to rewrite one FAT entry.
struct Cfb {
    bytes: Vec<u8>,
    sector: usize,
}
impl Cfb {
    fn new(bytes: Vec<u8>) -> Self {
        let sector = 1 << u16::from_le_bytes([bytes[0x1E], bytes[0x1F]]);
        Self { bytes, sector }
    }
    fn u32_at(&self, at: usize) -> u32 {
        u32::from_le_bytes(self.bytes[at..at + 4].try_into().unwrap())
    }
    fn fat_entry(&self, i: u32) -> usize {
        let per = self.sector / 4;
        let fat_sector = self.u32_at(0x4C + 4 * (i as usize / per));
        (fat_sector as usize + 1) * self.sector + 4 * (i as usize % per)
    }
    fn chain(&self, start: u32) -> Vec<u32> {
        let mut out = vec![start];
        while let next @ 0..=0xFFFF_FFF9 = self.u32_at(self.fat_entry(*out.last().unwrap())) {
            out.push(next);
        }
        out
    }
    fn point(&mut self, from: u32, to: u32) {
        let at = self.fat_entry(from);
        self.bytes[at..at + 4].copy_from_slice(&to.to_le_bytes());
    }
}

/// Whether the preview found the dialogue file in the media folder, relinked from `locator`.
fn found_in_media_folder(f: &AafFolder, preview: &Value) {
    let plan = &preview["plan"];
    let warnings: Vec<_> = plan["warnings"].as_array().unwrap().iter().filter_map(|w| w.as_str()).collect();
    assert!(!warnings.iter().any(|w| w.starts_with("Missing media")), "{warnings:?}");
    assert_eq!(plan["sources"].as_array().unwrap().len(), 2, "{warnings:?}");
    let found = std::fs::canonicalize(&f.dir).unwrap().join("Diálogo á #1.wav");
    assert_eq!(plan["sources"][0]["path"], json!(found.display().to_string()));
    assert!(warnings.iter().any(|w| w.starts_with("Relinked ")), "{warnings:?}");
}

#[test]
fn a_locator_from_a_mac_finds_its_file_in_the_chosen_media_folder() {
    let f = AafFolder::new();
    let preview = with_locator(&f, "file:///Users/Diálogo á %231.wav").unwrap();
    found_in_media_folder(&f, &preview);
}

#[test]
fn a_locator_from_windows_finds_its_file_in_the_chosen_media_folder() {
    let f = AafFolder::new();
    let preview = with_locator(&f, "file:///C:/me/Diálogo á %231.wav").unwrap();
    found_in_media_folder(&f, &preview);
}

#[test]
fn looped_sector_chains_fail_instead_of_hanging() {
    let fixture = std::fs::read(concat!(env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/synthetic-two-tracks.aaf")).unwrap();
    let base = Cfb::new(fixture);
    let root_start = base.u32_at(base.sector + 0x74);
    // (chain, start sector): directory, mini FAT, mini stream (root entry).
    let chains = [("directory", base.u32_at(0x30)), ("mini FAT", base.u32_at(0x3C)), ("mini stream", root_start)];
    for (name, start) in chains {
        let chain = base.chain(start);
        assert!(chain.len() >= 2, "{name}: fixture chain too short to loop");
        let last = *chain.last().unwrap();
        // Back to the start, and onto itself in the middle (a sector reached twice).
        for (from, to) in [(last, start), (chain[1], chain[1])] {
            let mut cfb = Cfb::new(base.bytes.clone());
            cfb.point(from, to);
            let f = AafFolder::new();
            let aaf = f.dir.join("Montaje sintético.aaf");
            std::fs::write(&aaf, &cfb.bytes).unwrap();
            let (tx, rx) = std::sync::mpsc::channel();
            let media = f.dir.clone();
            std::thread::spawn(move || {
                let _ = tx.send(Engine::default().execute("file.preview_aaf", &json!({"path": aaf, "media_dir": media})).map(|_| ()));
            });
            let result =
                rx.recv_timeout(std::time::Duration::from_secs(30)).unwrap_or_else(|_| panic!("{name} {from}->{to}: reader did not terminate"));
            assert!(result.is_err(), "{name} {from}->{to}: a looped chain was accepted");
        }
    }
}

#[test]
fn relinked_sources_are_reported_once_however_many_edits_use_them() {
    let f = AafFolder::new();
    let moved = f.dir.join("moved media");
    std::fs::create_dir(&moved).unwrap();
    for name in ["Diálogo á #1.wav", "Ambiente estéreo.wav"] {
        std::fs::rename(f.dir.join(name), moved.join(name)).unwrap();
    }
    let aaf = f.dir.join("Montaje sintético.aaf");
    let preview = Engine::default().execute("file.preview_aaf", &json!({"path": aaf, "media_dir": moved})).unwrap();
    let relinks = preview["plan"]["warnings"].as_array().unwrap().iter().filter(|w| w.as_str().unwrap().starts_with("Relinked ")).count();
    // Three edits, two source files: the dialogue source is used twice.
    assert_eq!(relinks, 2);
    assert_eq!(preview["plan"]["sources"].as_array().unwrap().len(), 2);
}

#[test]
fn an_unknown_composition_id_is_refused() {
    let f = AafFolder::new();
    let aaf = f.dir.join("Montaje sintético.aaf");
    let err = Engine::default()
        .execute("file.preview_aaf", &json!({"path": aaf, "media_dir": f.dir, "composition": "urn:smpte:umid:00"}))
        .unwrap_err()
        .to_string();
    assert!(err.contains("Choose exactly one composition"), "{err}");
}

#[test]
fn repeated_local_mob_references_fail_before_property_expansion() {
    // A small index can otherwise expand one storage's properties once per repeated reference.
    let mut bytes = std::fs::read(concat!(env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/synthetic-two-tracks.aaf")).unwrap();
    let mut index = Vec::new();
    {
        let mut cfb = cfb::CompoundFile::open(Cursor::new(bytes.as_slice())).unwrap();
        cfb.open_stream("/Header-2/Content-3b03/Mobs-1901 index").unwrap().read_to_end(&mut index).unwrap();
    }
    let count = u32::from_le_bytes(index[0..4].try_into().unwrap()) as usize;
    let key_size = usize::from(index[14]);
    assert!(count >= 2 && matches!(key_size, 16 | 32));
    let entry = 8 + key_size;
    let original_index = index.clone();
    let first_local = index[15..19].to_vec();
    index[15 + entry..19 + entry].copy_from_slice(&first_local);

    // This small stream is contiguous in the fixture's mini stream; replace only its index bytes.
    let at = bytes.windows(original_index.len()).position(|window| window == original_index.as_slice()).unwrap();
    bytes[at..at + index.len()].copy_from_slice(&index);

    let f = AafFolder::new();
    std::fs::write(f.dir.join("Montaje sintético.aaf"), bytes).unwrap();
    let err = f.preview().unwrap_err().to_string();
    assert!(err.contains("duplicate local reference in mobs"), "{err}");
}
