//! The MIDI Editor: a piano roll with velocity lane, 10x independent X/Y zoom, FL Studio scale
//! highlighting, ghost notes, playlist bar ruler, live playhead, key audition, and Studio One
//! cut-to-grid / copy-paste / double-click editing.

use crate::SoundApp;
use crate::theme::{Tokens, bold, regular};
use egui::{Align2, Color32, Rect, Sense, Stroke, StrokeKind, Ui, pos2, vec2};
use serde_json::json;
use soundcraft_midi::Note;
use soundcraft_model::{ClipContent, ClipId, Tool, TrackId};
use soundcraft_time::TICKS_PER_QUARTER;

const KEY_W: f32 = 54.0;
const BASE_ROW_H: f32 = 10.0;
const VEL_H: f32 = 60.0;
const HEADER_H: f32 = 24.0;
const CONTROLS_H: f32 = 28.0;
const RULER_H: f32 = 20.0;
const MIN_ZOOM: f32 = 1.0;
const MAX_ZOOM: f32 = 30.0;

const KEY_NAMES: [&str; 12] = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ScaleDef {
    pub name: &'static str,
    pub intervals: &'static [i32],
}

/// Complete FL Studio scale catalog.
pub const FL_SCALES: &[ScaleDef] = &[
    ScaleDef { name: "None (Off)", intervals: &[] },
    ScaleDef { name: "Major (Ionian)", intervals: &[0, 2, 4, 5, 7, 9, 11] },
    ScaleDef { name: "Natural Minor (Aeolian)", intervals: &[0, 2, 3, 5, 7, 8, 10] },
    ScaleDef { name: "Harmonic Minor", intervals: &[0, 2, 3, 5, 7, 8, 11] },
    ScaleDef { name: "Melodic Minor", intervals: &[0, 2, 3, 5, 7, 9, 11] },
    ScaleDef { name: "Dorian", intervals: &[0, 2, 3, 5, 7, 9, 10] },
    ScaleDef { name: "Phrygian", intervals: &[0, 1, 3, 5, 7, 8, 10] },
    ScaleDef { name: "Phrygian Dominant", intervals: &[0, 1, 4, 5, 7, 8, 10] },
    ScaleDef { name: "Lydian", intervals: &[0, 2, 4, 6, 7, 9, 11] },
    ScaleDef { name: "Mixolydian", intervals: &[0, 2, 4, 5, 7, 9, 10] },
    ScaleDef { name: "Locrian", intervals: &[0, 1, 3, 5, 6, 8, 10] },
    ScaleDef { name: "Major Pentatonic", intervals: &[0, 2, 4, 7, 9] },
    ScaleDef { name: "Minor Pentatonic", intervals: &[0, 3, 5, 7, 10] },
    ScaleDef { name: "Blues", intervals: &[0, 3, 5, 6, 7, 10] },
    ScaleDef { name: "Whole Tone", intervals: &[0, 2, 4, 6, 8, 10] },
    ScaleDef { name: "Diminished (Half-Whole)", intervals: &[0, 1, 3, 4, 6, 7, 9, 10] },
    ScaleDef { name: "Diminished (Whole-Half)", intervals: &[0, 2, 3, 5, 6, 8, 9, 11] },
    ScaleDef { name: "Arabic", intervals: &[0, 2, 4, 5, 6, 8, 10] },
    ScaleDef { name: "Byzantine", intervals: &[0, 1, 4, 5, 7, 8, 11] },
    ScaleDef { name: "Double Harmonic", intervals: &[0, 1, 4, 5, 7, 8, 11] },
    ScaleDef { name: "Hungarian Minor", intervals: &[0, 2, 3, 6, 7, 8, 11] },
    ScaleDef { name: "Japanese (Insen)", intervals: &[0, 1, 5, 7, 10] },
    ScaleDef { name: "Neapolitan Major", intervals: &[0, 1, 3, 5, 7, 9, 11] },
    ScaleDef { name: "Neapolitan Minor", intervals: &[0, 1, 3, 5, 7, 8, 11] },
    ScaleDef { name: "Prometheus", intervals: &[0, 2, 4, 6, 9, 10] },
    ScaleDef { name: "Enigmatic", intervals: &[0, 1, 4, 6, 8, 10, 11] },
];

#[derive(Debug, Clone)]
pub struct MidiEditorState {
    pub selected: Vec<usize>,
    pub drag: Option<NoteDrag>,
    pub scroll_x: f32,
    pub scroll_y: f32,
    pub zoom_x: f32,
    pub zoom_y: f32,
    pub clip: Option<ClipId>,
    pub band: Option<egui::Pos2>,
    pub scale_root: usize,
    pub scale_index: usize,
    pub show_ghost_notes: bool,
    pub clipboard: Vec<Note>,
    pub auditioning_pitch: Option<u8>,
    pub active_velocity: Option<u8>,
}

impl Default for MidiEditorState {
    fn default() -> Self {
        Self {
            selected: Vec::new(),
            drag: None,
            scroll_x: 0.0,
            scroll_y: 0.0,
            zoom_x: 1.0,
            zoom_y: 1.0,
            clip: None,
            band: None,
            scale_root: 0,
            scale_index: 0,
            show_ghost_notes: true,
            clipboard: Vec::new(),
            auditioning_pitch: None,
            active_velocity: None,
        }
    }
}

impl MidiEditorState {
    fn switch_clip(&mut self, id: ClipId) {
        if self.clip != Some(id) {
            self.selected.clear();
            self.drag = None;
            self.band = None;
            self.scroll_x = 0.0;
        }
        self.clip = Some(id);
    }

    fn note_in_scale(&self, pitch: i32) -> bool {
        let Some(scale) = FL_SCALES.get(self.scale_index) else { return false };
        if scale.intervals.is_empty() {
            return false;
        }
        let degree = (pitch - self.scale_root as i32).rem_euclid(12);
        scale.intervals.contains(&degree)
    }
}

#[derive(Debug, Clone)]
pub struct NoteDrag {
    pub index: usize,
    pub resize: bool,
    pub start: egui::Pos2,
    pub dx_ticks: i64,
    pub dy_semi: i64,
}

pub fn target_clip(app: &SoundApp) -> Option<ClipId> {
    let s = app.engine.session();
    for id in &s.edit.selected_clips {
        if let Some((_, c)) = s.find_clip(*id)
            && matches!(c.content, ClipContent::Midi { .. })
        {
            return Some(*id);
        }
    }
    let at = s.edit.selection.start;
    s.tracks
        .iter()
        .filter(|t| s.edit.selected_tracks.contains(&t.id) && t.kind.is_midi())
        .flat_map(|t| t.clips().iter())
        .find(|c| c.range().contains(at) || c.range().overlaps(&s.edit.selection))
        .or_else(|| s.tracks.iter().filter(|t| s.edit.selected_tracks.contains(&t.id) && t.kind.is_midi()).flat_map(|t| t.clips().iter()).next())
        .map(|c| c.id)
}

fn is_black(p: i32) -> bool {
    matches!(p.rem_euclid(12), 1 | 3 | 6 | 8 | 10)
}

#[derive(Clone, Copy)]
struct Roll<'a> {
    sequence: &'a soundcraft_midi::Sequence,
    roll: Rect,
    keys: Rect,
    ruler: Rect,
    vel: Rect,
    px_per_tick: f32,
    row_h: f32,
    base_tick: i64,
    len_ticks: i64,
    scroll_x: f32,
    scroll_y: f32,
    grid_ticks: i64,
    rows: i32,
}

impl Roll<'_> {
    fn x_of(&self, tick: i64) -> f32 {
        self.roll.min.x + tick as f32 * self.px_per_tick - self.scroll_x
    }

    fn tick_at(&self, x: f32) -> f32 {
        (x - self.roll.min.x + self.scroll_x) / self.px_per_tick.max(1e-6)
    }

    fn y_of(&self, pitch: i32) -> f32 {
        self.roll.min.y + (127 - pitch) as f32 * self.row_h - self.scroll_y
    }

    fn pitch_at(&self, y: f32) -> i32 {
        127 - ((y - self.roll.min.y + self.scroll_y) / self.row_h.max(1e-6)).floor() as i32
    }

    fn hit(&self, pos: egui::Pos2) -> Option<(usize, bool)> {
        if !self.roll.contains(pos) {
            return None;
        }
        self.sequence.notes.iter().enumerate().rev().find_map(|(i, n)| {
            let x0 = self.x_of(n.start);
            let x1 = self.x_of(n.start + n.length).max(x0 + 4.0);
            let y0 = self.y_of(i32::from(n.pitch));
            let r = Rect::from_min_max(pos2(x0, y0), pos2(x1, y0 + self.row_h));
            r.contains(pos).then_some((i, pos.x > r.max.x - 5.0))
        })
    }

    fn snap_round(&self, tk: f32) -> i64 {
        ((tk / self.grid_ticks as f32).round() as i64) * self.grid_ticks
    }

    fn snap_floor(&self, tk: f32) -> i64 {
        ((tk / self.grid_ticks as f32).floor() as i64) * self.grid_ticks
    }
}

/// Anchor point for zoom changes: center of selected notes, or C3 (MIDI 60) at clip start when
/// nothing is selected.
fn zoom_anchor(sequence: &soundcraft_midi::Sequence, selected: &[usize]) -> (i64, i32) {
    let valid: Vec<&Note> = selected.iter().filter_map(|&i| sequence.notes.get(i)).collect();
    if valid.is_empty() {
        return (0, 60); // C3 = MIDI 60
    }
    let min_t = valid.iter().map(|n| n.start).min().unwrap_or(0);
    let max_t = valid.iter().map(|n| n.start + n.length).max().unwrap_or(0);
    let min_p = valid.iter().map(|n| i32::from(n.pitch)).min().unwrap_or(60);
    let max_p = valid.iter().map(|n| i32::from(n.pitch)).max().unwrap_or(60);
    ((min_t + max_t) / 2, (min_p + max_p) / 2)
}

pub fn show(app: &mut SoundApp, ui: &mut Ui) {
    ui.take_available_space();
    let t = Tokens::current();
    let full = ui.max_rect();
    ui.painter().rect_filled(full, 0.0, t.panel_bg);

    let header = Rect::from_min_size(full.min, vec2(full.width(), HEADER_H));
    ui.painter().rect_filled(header, 0.0, t.panel_bg2);
    ui.painter().text(
        pos2(header.min.x + 8.0, header.center().y),
        Align2::LEFT_CENTER,
        crate::localization::text("MIDI EDITOR"),
        bold(11.5),
        t.header_text,
    );

    let Some(cid) = target_clip(app) else {
        empty_state(app, ui, full, header);
        return;
    };
    let Some((track, clip)) = app.engine.session().find_clip(cid).map(|(t, c)| (t, c.clone())) else {
        return;
    };
    let ClipContent::Midi { sequence } = &clip.content else {
        return;
    };
    let track_color = app.engine.session().track(track).map_or([120, 120, 200], |t| t.color);

    let s = app.engine.session_arc();
    let sr = s.sample_rate;
    let base_tick = s.tempo.samples_to_ticks(clip.start, sr);
    let end_tick = s.tempo.samples_to_ticks(clip.end(), sr);
    let len_ticks = (end_tick - base_tick).max(1);
    let bar_ticks = (TICKS_PER_QUARTER * 4).max(1);
    let start_bar = (base_tick / bar_ticks) + 1;
    let end_bar = ((end_tick.saturating_sub(1).max(base_tick)) / bar_ticks) + 1;

  let vel_readout = match app.midi.active_velocity {
    Some(v) => format!(" · Vel: {v}"),
    None => app
        .midi
        .selected
        .first()
        .and_then(|&idx| sequence.notes.get(idx))
        .map(|n| format!(" · Vel: {}", n.velocity))
        .unwrap_or_default(),
};
ui.painter().text(
    pos2(header.min.x + 104.0, header.center().y),
    Align2::LEFT_CENTER,
    format!(
        "{} · Bars {}-{} · {} notes · {} sel{}",
        clip.name,
        start_bar,
        end_bar,
        sequence.notes.len(),
        app.midi.selected.len(),
        vel_readout
    ),
    regular(11.0),
    t.text_dim,
);

    let grid_ticks = grid_ticks_of(app);
    midi_toolbar(app, ui, header, cid, sequence, grid_ticks);

    // Controls bar (Scale dropdowns, Ghost Notes toggle, and spaced X/Y Zoom sliders).
    let controls = Rect::from_min_size(pos2(full.min.x, header.max.y + 2.0), vec2(full.width(), CONTROLS_H));
    ui.painter().rect_filled(controls, 0.0, t.panel_bg2.gamma_multiply(0.85));

    // Layout geometry with generous spacing below the controls bar so sliders never overlap the roll.
    let ruler = Rect::from_min_size(pos2(full.min.x + KEY_W, controls.max.y + 4.0), vec2((full.width() - KEY_W - 6.0).max(40.0), RULER_H));
    let roll = Rect::from_min_max(pos2(full.min.x + KEY_W, ruler.max.y), pos2(full.max.x - 6.0, full.max.y - VEL_H - 6.0));
    let keys = Rect::from_min_max(pos2(full.min.x, roll.min.y), pos2(roll.min.x, roll.max.y));
    let vel = Rect::from_min_max(pos2(roll.min.x, roll.max.y + 4.0), pos2(roll.max.x, full.max.y - 2.0));

    let prev_zoom_x = app.midi.zoom_x;
    let prev_zoom_y = app.midi.zoom_y;
    controls_bar(app, ui, controls);

    let zoom_x = app.midi.zoom_x.clamp(MIN_ZOOM, MAX_ZOOM);
    let zoom_y = app.midi.zoom_y.clamp(MIN_ZOOM, MAX_ZOOM);
    let row_h = BASE_ROW_H * zoom_y;
    let base_px_per_tick = roll.width().max(1.0) / len_ticks as f32;
    let px_per_tick = base_px_per_tick * zoom_x;

    if app.midi.clip != Some(cid) {
        let (_, anchor_pitch) = zoom_anchor(sequence, &[]);
        app.midi.scroll_y = (127 - anchor_pitch) as f32 * row_h - roll.height() * 0.5;
        app.midi.switch_clip(cid);
    }

    // Re-center on selected note (or C3 if none selected) when Zoom X or Zoom Y sliders move.
    let (anchor_tick, anchor_pitch) = zoom_anchor(sequence, &app.midi.selected);
    if (zoom_x - prev_zoom_x).abs() > 1e-4 {
        app.midi.scroll_x = anchor_tick as f32 * px_per_tick - roll.width() * 0.5;
    }
    if (zoom_y - prev_zoom_y).abs() > 1e-4 {
        app.midi.scroll_y = (127 - anchor_pitch) as f32 * row_h - roll.height() * 0.5;
    }

    // Pointer wheel scrolling & modifier zooming over the piano roll.
    if ui.rect_contains_pointer(roll) {
        let (scroll_delta, ctrl_or_cmd, shift_or_alt) = ui.input(|i| {
            (
                i.smooth_scroll_delta,
                i.modifiers.ctrl || i.modifiers.command,
                i.modifiers.shift || i.modifiers.alt,
            )
        });
        if ctrl_or_cmd && scroll_delta.y.abs() > 0.0 {
            let factor = (1.0 + scroll_delta.y * 0.003).clamp(0.5, 2.0);
            app.midi.zoom_x = (app.midi.zoom_x * factor).clamp(MIN_ZOOM, MAX_ZOOM);
            let new_px = base_px_per_tick * app.midi.zoom_x;
            app.midi.scroll_x = anchor_tick as f32 * new_px - roll.width() * 0.5;
        } else if shift_or_alt && scroll_delta.y.abs() > 0.0 {
            let factor = (1.0 + scroll_delta.y * 0.003).clamp(0.5, 2.0);
            app.midi.zoom_y = (app.midi.zoom_y * factor).clamp(MIN_ZOOM, MAX_ZOOM);
            let new_row_h = BASE_ROW_H * app.midi.zoom_y;
            app.midi.scroll_y = (127 - anchor_pitch) as f32 * new_row_h - roll.height() * 0.5;
        } else {
            app.midi.scroll_y -= scroll_delta.y;
            app.midi.scroll_x -= scroll_delta.x;
        }
    }

    let row_h = BASE_ROW_H * app.midi.zoom_y;
    let px_per_tick = base_px_per_tick * app.midi.zoom_x;
    let content_w = len_ticks as f32 * px_per_tick;
    let content_h = 128.0 * row_h;

    app.midi.scroll_x = app.midi.scroll_x.clamp(0.0, (content_w - roll.width()).max(0.0));
    app.midi.scroll_y = app.midi.scroll_y.clamp(0.0, (content_h - roll.height()).max(0.0));

    let g = Roll {
        sequence,
        roll,
        keys,
        ruler,
        vel,
        px_per_tick,
        row_h,
        base_tick,
        len_ticks,
        scroll_x: app.midi.scroll_x,
        scroll_y: app.midi.scroll_y,
        grid_ticks,
        rows: (roll.height() / row_h).floor() as i32,
    };

    // Draw Bar Ruler (Bars 1-5 etc. matching playlist).
    draw_bar_ruler(&ui.painter().with_clip_rect(ruler), &g);

    // Draw Roll Background & Scale Highlighting strictly inside `roll` (never overlapping `keys`).
    let roll_painter = ui.painter().with_clip_rect(roll);
    draw_roll_background(&roll_painter, &g, &app.midi);

    // Draw Ghost Notes from other MIDI clips in the playlist.
    if app.midi.show_ghost_notes {
        draw_ghost_notes(app, &roll_painter, &g, cid, track);
    }

    // Draw Active Clip Notes strictly inside `roll`.
    let base = Color32::from_rgb(track_color[0], track_color[1], track_color[2]);
    draw_notes(app, &roll_painter, &g, base);

    // Click or drag the ruler to scrub/move the playhead inside the MIDI editor.
    let ruler_resp = ui.interact(ruler, ui.scope_id().with(("midi_ruler", cid.0)), Sense::click_and_drag());
    if (ruler_resp.clicked() || ruler_resp.dragged())
        && let Some(pos) = ruler_resp.interact_pointer_pos()
    {
        let local_tick = (g.tick_at(pos.x).round() as i64).clamp(0, len_ticks);
        let target_samples = s.tempo.tick_to_samples((base_tick + local_tick).max(0), sr);
        let _ = app.run("transport.locate", json!({ "at": target_samples }));
    }

    // Draw Synchronized Transport Playhead inside `roll` and `ruler`.
    let playhead_samples = app.position();
    let playhead_tick = s.tempo.samples_to_ticks(playhead_samples, sr) - base_tick;
    if (0..=len_ticks).contains(&playhead_tick) {
        let px = g.x_of(playhead_tick);
        roll_painter.line_segment([pos2(px, roll.min.y), pos2(px, roll.max.y)], Stroke::new(1.5, t.playhead));
        let ruler_painter = ui.painter().with_clip_rect(ruler);
        ruler_painter.line_segment([pos2(px, ruler.min.y), pos2(px, ruler.max.y)], Stroke::new(1.5, t.playhead));
    }

    // Draw Interactive Piano Keyboard strictly inside `keys` (never overlapped by notes).
    let keys_painter = ui.painter().with_clip_rect(keys);
    draw_and_interact_piano_keys(app, ui, &keys_painter, &g, track);

    // Roll pointer and keyboard actions.
    note_pointer(app, ui, &g, cid, track, s.edit.tool == Tool::Pencil);
    note_keys(app, ui, &g, cid, playhead_tick);
    velocity_lane(app, ui, &g, cid, base, full.min.x + 6.0);
}

fn controls_bar(app: &mut SoundApp, ui: &mut Ui, controls: Rect) {
    let mut bar = ui.new_child(egui::UiBuilder::new().max_rect(controls.shrink2(vec2(8.0, 2.0))).layout(egui::Layout::left_to_right(egui::Align::Center)));
    bar.spacing_mut().item_spacing.x = 8.0;

    // Key root dropdown
    bar.label(egui::RichText::new("Key:").size(11.0));
    egui::ComboBox::from_id_salt("midi_scale_root")
        .width(46.0)
        .selected_text(KEY_NAMES[app.midi.scale_root % 12])
        .show_ui(&mut bar, |ui| {
            for (idx, name) in KEY_NAMES.iter().enumerate() {
                ui.selectable_value(&mut app.midi.scale_root, idx, *name);
            }
        });

    // FL Studio Scale dropdown
    bar.label(egui::RichText::new("Scale:").size(11.0));
    let current_scale_name = FL_SCALES.get(app.midi.scale_index).map_or("None (Off)", |s| s.name);
    egui::ComboBox::from_id_salt("midi_scale_kind")
        .width(150.0)
        .selected_text(current_scale_name)
        .show_ui(&mut bar, |ui| {
            for (idx, sc) in FL_SCALES.iter().enumerate() {
                ui.selectable_value(&mut app.midi.scale_index, idx, sc.name);
            }
        });

    bar.separator();

    // Ghost notes toggle
    bar.toggle_value(&mut app.midi.show_ghost_notes, "Ghost Notes");

    bar.separator();

    if bar.button("Copy Notes").on_hover_text("Copy selected MIDI notes only").clicked()
        && !app.midi.selected.is_empty()
        && let Some(cid) = app.midi.clip
        && let Some((_, clip)) = app.engine.session().find_clip(cid)
        && let ClipContent::Midi { sequence } = &clip.content
    {
        app.midi.clipboard = app.midi.selected.iter().filter_map(|&idx| sequence.notes.get(idx).copied()).collect();
    }

    if bar.button("Paste Notes").on_hover_text("Paste copied MIDI notes at the playhead").clicked()
        && !app.midi.clipboard.is_empty()
        && let Some(cid) = app.midi.clip
    {
        let s = app.engine.session_arc();
        let base_tick = s
            .find_clip(cid)
            .map(|(_, c)| s.tempo.samples_to_ticks(c.start, s.sample_rate))
            .unwrap_or(0);
        let playhead_tick = (s.tempo.samples_to_ticks(app.position(), s.sample_rate) - base_tick).max(0);
        paste_midi_clipboard(app, cid, playhead_tick);
    }

    bar.separator();

    // Independent 20x X and Y zoom sliders
    bar.label(egui::RichText::new("Zoom X:").size(11.0));
    bar.add(egui::Slider::new(&mut app.midi.zoom_x, MIN_ZOOM..=MAX_ZOOM).show_value(true).suffix("x").max_decimals(1));

    bar.add_space(6.0);

    bar.label(egui::RichText::new("Zoom Y:").size(11.0));
    bar.add(egui::Slider::new(&mut app.midi.zoom_y, MIN_ZOOM..=MAX_ZOOM).show_value(true).suffix("x").max_decimals(1));
}

fn paste_midi_clipboard(app: &mut SoundApp, cid: ClipId, target_base: i64) {
    let min_start = app.midi.clipboard.iter().map(|n| n.start).min().unwrap_or(0);
    let notes_to_paste = app.midi.clipboard.clone();
    for n in notes_to_paste {
        let offset = n.start - min_start;
        let _ = app.run(
            "midi.note_add",
            json!({
                "clip": cid.0,
                "pitch": n.pitch,
                "start_ticks": target_base + offset,
                "length_ticks": n.length,
                "velocity": n.velocity,
                "channel": n.channel,
            }),
        );
    }
}

fn empty_state(app: &mut SoundApp, ui: &mut Ui, full: Rect, header: Rect) {
    let t = Tokens::current();
    let track = {
        let s = app.engine.session();
        s.tracks.iter().find(|t| t.kind.is_midi() && s.edit.selected_tracks.contains(&t.id)).map(|t| (t.id, t.name.clone()))
    };
    let msg = match &track {
        Some((_, name)) => crate::localized_format!("Click to add a MIDI clip to {name} at the insertion point.", name = name),
        None => crate::localization::text("Select a MIDI clip (or a MIDI track) to edit its notes.").into(),
    };
    ui.painter().text(full.center(), Align2::CENTER_CENTER, msg, regular(13.0), t.text_dim);
    let body = Rect::from_min_max(pos2(full.min.x, header.max.y), full.max);
    if let Some((id, _)) = track
        && ui.interact(body, ui.scope_id().with("new_clip"), Sense::click()).clicked()
    {
        let sel = app.engine.session().edit.selection;
        if let Ok(v) = app.run("midi.new_clip", json!({"track": id.0, "start": sel.start, "end": sel.end})) {
            let _ = app.run("edit.select", json!({"clips": [v["clip"]]}));
        }
    }
}

fn grid_ticks_of(app: &SoundApp) -> i64 {
    match app.engine.session().edit.grid {
        soundcraft_time::GridValue::Note { value, dotted, triplet } => {
            let mut g = value.ticks();
            if dotted {
                g = g * 3 / 2;
            }
            if triplet {
                g = g * 2 / 3;
            }
            g.max(1)
        }
        _ => TICKS_PER_QUARTER / 4,
    }
}

fn midi_toolbar(app: &mut SoundApp, ui: &mut Ui, header: Rect, cid: ClipId, sequence: &soundcraft_midi::Sequence, grid_ticks: i64) {
    let bar = Rect::from_min_max(pos2(header.max.x - 420.0, header.min.y + 1.0), pos2(header.max.x - 6.0, header.max.y - 1.0));
    let mut tb = ui.new_child(egui::UiBuilder::new().max_rect(bar).layout(egui::Layout::right_to_left(egui::Align::Center)));
    tb.spacing_mut().item_spacing.x = 4.0;
    let mut op: Option<(&str, serde_json::Value)> = None;

    if tb.small_button(crate::localization::text("Cut to Grid")).on_hover_text("Slice notes along grid lines (Studio One style)").clicked() {
        cut_notes_to_grid(app, cid, sequence, grid_ticks);
    }
    if tb.small_button(crate::localization::text("Legato")).clicked() {
        op = Some(("event.change_duration", json!({"legato": 0})));
    }
    if tb.small_button(crate::localization::text("Vel −10")).clicked() {
        op = Some(("event.change_velocity", json!({"add": -10})));
    }
    if tb.small_button(crate::localization::text("Vel +10")).clicked() {
        op = Some(("event.change_velocity", json!({"add": 10})));
    }
    if tb.small_button(crate::localization::text("Quantize")).on_hover_text(crate::localization::text("Quantize to the grid")).clicked() {
        op = Some(("event.quantize", json!({"grid": grid_ticks, "strength": 100})));
    }
    if let Some((id, mut p)) = op {
        p["clips"] = json!([cid.0]);
        let _ = app.run(id, p);
    }
}

/// Studio One-style Cut to Grid: splits selected notes (or all notes if none selected) at every
/// grid boundary they cross.
fn cut_notes_to_grid(app: &mut SoundApp, cid: ClipId, sequence: &soundcraft_midi::Sequence, grid_ticks: i64) {
    let g = grid_ticks.max(1);
    let targets: Vec<usize> = if app.midi.selected.is_empty() {
        (0..sequence.notes.len()).collect()
    } else {
        app.midi.selected.clone()
    };

    let mut to_delete = Vec::new();
    let mut to_add = Vec::new();

    for &idx in &targets {
        let Some(n) = sequence.notes.get(idx) else { continue };
        let start = n.start;
        let end = n.start + n.length;
        let first_cut = ((start / g) + 1) * g;
        if first_cut >= end {
            continue;
        }
        to_delete.push(idx);
        let mut cur = start;
        while cur < end {
            let next_cut = (((cur / g) + 1) * g).min(end);
            let seg_len = next_cut - cur;
            if seg_len > 0 {
                to_add.push((n.pitch, cur, seg_len, n.velocity, n.channel));
            }
            cur = next_cut;
        }
    }

    if to_delete.is_empty() {
        return;
    }

    let _ = app.run("midi.note_delete", json!({"clip": cid.0, "indices": to_delete}));
    for (pitch, start_ticks, length_ticks, velocity, channel) in to_add {
        let _ = app.run(
            "midi.note_add",
            json!({
                "clip": cid.0,
                "pitch": pitch,
                "start_ticks": start_ticks,
                "length_ticks": length_ticks,
                "velocity": velocity,
                "channel": channel,
            }),
        );
    }
    app.midi.selected.clear();
}

/// Playlist-synchronized bar ruler at the top of the piano roll.
fn draw_bar_ruler(painter: &egui::Painter, g: &Roll<'_>) {
    let t = Tokens::current();
    let Roll { ruler, px_per_tick, base_tick, len_ticks, .. } = *g;
    painter.rect_filled(ruler, 0.0, t.panel_bg2);
    painter.line_segment([pos2(ruler.min.x, ruler.max.y - 0.5), pos2(ruler.max.x, ruler.max.y - 0.5)], Stroke::new(1.0, t.border));

    let bar_ticks = (TICKS_PER_QUARTER * 4).max(1);
    let first_bar_idx = base_tick / bar_ticks;
    let first_bar_offset = (first_bar_idx * bar_ticks) - base_tick;

    let mut tick = first_bar_offset;
    while tick <= len_ticks {
        let abs_tick = base_tick + tick;
        let bar_num = (abs_tick / bar_ticks) + 1;
        let x = g.x_of(tick);
        if x >= ruler.min.x - 40.0 && x <= ruler.max.x + 40.0 {
            painter.line_segment([pos2(x, ruler.min.y + 4.0), pos2(x, ruler.max.y)], Stroke::new(1.0, t.text_dim));
            painter.text(
                pos2(x + 4.0, ruler.center().y),
                Align2::LEFT_CENTER,
                format!("Bar {bar_num}"),
                bold(10.0),
                t.header_text,
            );
        }
        // Beat ticks inside each bar when zoomed in
        if bar_ticks as f32 * px_per_tick > 48.0 {
            for beat in 1..4 {
                let bx = g.x_of(tick + beat * TICKS_PER_QUARTER);
                if bx >= ruler.min.x && bx <= ruler.max.x {
                    painter.line_segment([pos2(bx, ruler.max.y - 6.0), pos2(bx, ruler.max.y)], Stroke::new(1.0, t.border));
                }
            }
        }
        tick = tick.saturating_add(bar_ticks);
    }
}

/// Background rows with uniform light-white scale highlighting and grid lines.
fn draw_roll_background(painter: &egui::Painter, g: &Roll<'_>, state: &MidiEditorState) {
    let Roll { roll, px_per_tick, row_h, len_ticks, grid_ticks, rows, .. } = *g;
    let top = g.pitch_at(roll.min.y);
    let scale_active = FL_SCALES.get(state.scale_index).is_some_and(|s| !s.intervals.is_empty());

    for r in 0..=rows + 2 {
        let pitch = top - r;
        if !(0..=127).contains(&pitch) {
            continue;
        }
        let y = g.y_of(pitch);
        let row = Rect::from_min_size(pos2(roll.min.x, y), vec2(roll.width(), row_h));
        let base_bg = if is_black(pitch) { Color32::from_rgb(28, 28, 31) } else { Color32::from_rgb(36, 36, 40) };
        painter.rect_filled(row, 0.0, base_bg);

        // Uniform, consistent light-white highlight for every note inside the chosen scale.
        if scale_active && state.note_in_scale(pitch) {
            painter.rect_filled(row, 0.0, Color32::from_rgba_unmultiplied(255, 255, 255, 22));
        }

        if pitch.rem_euclid(12) == 0 {
            painter.line_segment([pos2(roll.min.x, y + row_h), pos2(roll.max.x, y + row_h)], Stroke::new(1.0, Color32::from_rgb(66, 66, 72)));
        } else {
            painter.line_segment([pos2(roll.min.x, y + row_h), pos2(roll.max.x, y + row_h)], Stroke::new(0.5, Color32::from_rgb(46, 46, 50)));
        }
    }

    let bar_ticks = (TICKS_PER_QUARTER * 4).max(1);
let sub_ticks = g.grid_ticks.max(1);
let first_sub_idx = g.base_tick.div_euclid(sub_ticks);
let last_sub_idx = (g.base_tick + g.len_ticks).div_euclid(sub_ticks);
for sub_idx in first_sub_idx..=last_sub_idx {
    if sub_idx.rem_euclid(2) == 1 {
        let sub_start_tick = sub_idx * sub_ticks - g.base_tick;
        let sub_end_tick = (sub_idx + 1) * sub_ticks - g.base_tick;
        let x0 = g.x_of(sub_start_tick).max(roll.min.x);
        let x1 = g.x_of(sub_end_tick).min(roll.max.x);
        if x1 > x0 {
            let col_rect = Rect::from_min_max(pos2(x0, roll.min.y), pos2(x1, roll.max.y));
            painter.rect_filled(col_rect, 0.0, Color32::from_rgba_unmultiplied(255, 255, 255, 5));
        }
    }
}

    let step = grid_stride(grid_ticks, px_per_tick);
    let mut tick = 0;
    while tick <= len_ticks {
        let x = g.x_of(tick);
        if x >= roll.min.x - 2.0 && x <= roll.max.x + 2.0 {
            let is_bar = (g.base_tick + tick) % bar_ticks == 0;
            painter.line_segment(
                [pos2(x, roll.min.y), pos2(x, roll.max.y)],
                Stroke::new(1.0, if is_bar { Color32::from_rgb(84, 84, 92) } else { Color32::from_rgb(50, 50, 56) }),
            );
        }
        tick = tick.saturating_add(step);
    }
}

/// Interactive piano keys drawn in `keys` with click/drag note audition.
fn draw_and_interact_piano_keys(app: &mut SoundApp, ui: &mut Ui, painter: &egui::Painter, g: &Roll<'_>, track: TrackId) {
    let Roll { keys, row_h, rows, .. } = *g;
    let resp = ui.interact(keys, ui.scope_id().with("piano_keys"), Sense::click_and_drag());

    let hovered_pitch = if (resp.is_pointer_button_down_on() || resp.dragged())
        && let Some(pos) = resp.interact_pointer_pos()
        && keys.contains(pos)
    {
        Some(g.pitch_at(pos.y).clamp(0, 127) as u8)
    } else {
        None
    };

    if hovered_pitch != app.midi.auditioning_pitch {
        if let Some(prev) = app.midi.auditioning_pitch.take() {
            app.audition_note_off(prev);
        }
        if let Some(p) = hovered_pitch {
            app.audition_note_on(Some(track), p, 105);
            app.midi.auditioning_pitch = Some(p);
        }
    }

    let top = g.pitch_at(keys.min.y);
    for r in 0..=rows + 2 {
        let pitch = top - r;
        if !(0..=127).contains(&pitch) {
            continue;
        }
        let y = g.y_of(pitch);
        let key = Rect::from_min_size(pos2(keys.min.x, y), vec2(KEY_W - 2.0, (row_h - 1.0).max(2.0)));
        let active = app.midi.auditioning_pitch == Some(pitch as u8);
        let fill = if active {
            Tokens::current().accent
        } else if is_black(pitch) {
            Color32::from_rgb(22, 22, 24)
        } else {
            Color32::from_rgb(228, 228, 232)
        };
        painter.rect_filled(key, 1.0, fill);
        if pitch.rem_euclid(12) == 0 || row_h >= 16.0 {
            let label_col = if is_black(pitch) && !active { Color32::from_rgb(200, 200, 205) } else { Color32::from_rgb(35, 35, 38) };
            painter.text(
                pos2(key.max.x - 4.0, key.center().y),
                Align2::RIGHT_CENTER,
                soundcraft_midi::note_name(pitch as u8),
                regular(8.5),
                label_col,
            );
        }
    }
}

/// Ghost notes from other MIDI clips in the playlist overlapping the edited clip's timeline range.
fn draw_ghost_notes(app: &SoundApp, painter: &egui::Painter, g: &Roll<'_>, active_cid: ClipId, active_track: TrackId) {
    let s = app.engine.session();
    let sr = s.sample_rate;
    let clip_start_tick = g.base_tick;
    let clip_end_tick = g.base_tick + g.len_ticks;

    for tr in &s.tracks {
        if !tr.kind.is_midi() {
            continue;
        }
        let ghost_fill = Color32::from_rgba_unmultiplied(tr.color[0], tr.color[1], tr.color[2], 36);
        let ghost_stroke = Stroke::new(1.0, Color32::from_rgba_unmultiplied(tr.color[0], tr.color[1], tr.color[2], 80));
        for c in tr.clips() {
            if c.id == active_cid {
                continue;
            }
            if tr.id == active_track {
                continue;
            }
            let ClipContent::Midi { sequence } = &c.content else { continue };
            let c_base = s.tempo.samples_to_ticks(c.start, sr);
            let c_end = s.tempo.samples_to_ticks(c.end(), sr);
            if c_end < clip_start_tick || c_base > clip_end_tick {
                continue;
            }
            for n in &sequence.notes {
                let rel_start = (c_base + n.start) - clip_start_tick;
                let rel_end = rel_start + n.length;
                if rel_end < 0 || rel_start > g.len_ticks {
                    continue;
                }
                let p = i32::from(n.pitch);
                let x0 = g.x_of(rel_start);
                let x1 = g.x_of(rel_end).max(x0 + 3.0);
                let y0 = g.y_of(p) + 1.0;
                let r = Rect::from_min_max(pos2(x0, y0), pos2(x1, y0 + g.row_h - 1.0));
                painter.rect(r, 2.0, ghost_fill, ghost_stroke, StrokeKind::Inside);
            }
        }
    }
}

const MIN_GRID_PX: f32 = 4.0;

fn grid_stride(grid_ticks: i64, px_per_tick: f32) -> i64 {
    let bar_ticks = TICKS_PER_QUARTER * 4;
    if grid_ticks as f32 * px_per_tick > MIN_GRID_PX {
        return grid_ticks.max(1);
    }
    let grid = grid_ticks.max(1);
    let (mut a, mut b) = (grid, bar_ticks);
    while b != 0 {
        (a, b) = (b, a % b);
    }
    let common = (grid / a).saturating_mul(bar_ticks);
    let n = (MIN_GRID_PX / (common as f32 * px_per_tick)).ceil().max(1.0) as i64;
    common.saturating_mul(n)
}

fn draw_notes(app: &SoundApp, painter: &egui::Painter, g: &Roll<'_>, base: Color32) {
    let Roll { sequence, row_h, grid_ticks, .. } = *g;
    let drag = app.midi.drag.clone();
    for (i, n) in sequence.notes.iter().enumerate() {
        let (mut st, mut ln, mut p) = (n.start, n.length, i32::from(n.pitch));
        if let Some(d) = &drag
            && (d.index == i || (!d.resize && app.midi.selected.contains(&i) && app.midi.selected.contains(&d.index)))
        {
            if d.resize {
                if d.index == i {
                    ln = (ln + d.dx_ticks).max(grid_ticks.min(ln).max(1));
                }
            } else {
                st = (st + d.dx_ticks).max(0);
                p = (p + d.dy_semi as i32).clamp(0, 127);
            }
        }
        let x0 = g.x_of(st);
        let x1 = g.x_of(st + ln).max(x0 + 3.0);
        let y0 = g.y_of(p) + 1.0;
        let r = Rect::from_min_max(pos2(x0, y0), pos2(x1, y0 + (row_h - 1.0).max(2.0)));
        let sel = app.midi.selected.contains(&i);
        let k = 0.45 + 0.55 * f32::from(n.velocity) / 127.0;
        let fill = if sel {
            Color32::WHITE
        } else {
            Color32::from_rgb((f32::from(base.r()) * k) as u8, (f32::from(base.g()) * k) as u8, (f32::from(base.b()) * k) as u8)
        };
        painter.rect(r, 2.0, fill, Stroke::new(1.0, Color32::BLACK), StrokeKind::Inside);
    }
}

fn note_pointer(app: &mut SoundApp, ui: &mut Ui, g: &Roll<'_>, cid: ClipId, track: TrackId, pencil: bool) {
    let Roll { sequence, roll, px_per_tick, row_h, grid_ticks, .. } = *g;
    let resp = ui.interact(roll, ui.scope_id().with(("roll", cid.0)), Sense::click_and_drag());

    // Double-click empty space to create a note; double-click existing note to delete it.
    if resp.double_clicked()
        && let Some(p) = resp.interact_pointer_pos()
    {
        if let Some((i, _)) = g.hit(p) {
            let _ = app.run("midi.note_delete", json!({"clip": cid.0, "indices": [i]}));
            app.midi.selected.clear();
            return;
        } else {
            let pitch = g.pitch_at(p.y).clamp(0, 127);
            let start = g.snap_floor(g.tick_at(p.x)).max(0);
            let _ = app.run(
                "midi.note_add",
                json!({"clip": cid.0, "pitch": pitch, "start_ticks": start, "length_ticks": grid_ticks, "velocity": 100}),
            );
            app.audition_note_on(Some(track), pitch as u8, 100);
            app.audition_note_off(pitch as u8);
            app.midi.selected.clear();
            return;
        }
    }

    if resp.drag_started()
        && let Some(p) = resp.interact_pointer_pos()
    {
        if let Some((i, edge)) = g.hit(p) {
            if !app.midi.selected.contains(&i) {
                app.midi.selected = vec![i];
            }
            if let Some(n) = sequence.notes.get(i) {
                app.audition_note_on(Some(track), n.pitch, n.velocity);
                app.audition_note_off(n.pitch);
            }
            app.midi.drag = Some(NoteDrag { index: i, resize: edge, start: p, dx_ticks: 0, dy_semi: 0 });
        } else {
            app.midi.band = Some(p);
        }
    }

    if let (Some(a), Some(b)) = (app.midi.band, ui.ctx().pointer_latest_pos()) {
        let band = Rect::from_two_pos(a, b);
        ui.painter().with_clip_rect(roll).rect(
            band,
            0.0,
            Color32::from_rgba_unmultiplied(120, 170, 255, 40),
            Stroke::new(1.0, Color32::from_rgb(120, 170, 255)),
            StrokeKind::Inside,
        );
        if resp.drag_stopped() {
            app.midi.selected = sequence
                .notes
                .iter()
                .enumerate()
                .filter(|(_, n)| {
                    let r = Rect::from_min_max(
                        pos2(g.x_of(n.start), g.y_of(i32::from(n.pitch))),
                        pos2(g.x_of(n.start + n.length), g.y_of(i32::from(n.pitch)) + row_h),
                    );
                    r.intersects(band)
                })
                .map(|(i, _)| i)
                .collect();
            app.midi.band = None;
        }
    }

    if resp.dragged()
        && let Some(p) = resp.interact_pointer_pos()
    {
        let mut preview_audition: Option<(u8, u8)> = None;
        if let Some(d) = &mut app.midi.drag {
            d.dx_ticks = g.snap_round((p.x - d.start.x) / px_per_tick.max(1e-6));
            let new_dy = -((p.y - d.start.y) / row_h.max(1e-6)).round() as i64;
            if new_dy != d.dy_semi
                && !d.resize
                && let Some(n) = sequence.notes.get(d.index)
            {
                let preview_pitch = (i32::from(n.pitch) + new_dy as i32).clamp(0, 127) as u8;
                preview_audition = Some((preview_pitch, n.velocity));
            }
            d.dy_semi = new_dy;
        }
        if let Some((preview_pitch, vel)) = preview_audition {
            app.audition_note_on(Some(track), preview_pitch, vel);
            app.audition_note_off(preview_pitch);
        }
    }

    if resp.drag_stopped()
        && let Some(d) = app.midi.drag.take()
    {
        if d.resize {
            if let Some(n) = sequence.notes.get(d.index) {
                let _ = app.run("midi.note_edit", json!({"clip": cid.0, "index": d.index, "length_ticks": (n.length + d.dx_ticks).max(1)}));
            }
        } else if d.dx_ticks != 0 || d.dy_semi != 0 {
            let _ = app.run("midi.notes_move", json!({"clip": cid.0, "indices": app.midi.selected, "ticks": d.dx_ticks, "semitones": d.dy_semi}));
            app.midi.selected.clear();
        }
    }

    if resp.clicked()
        && let Some(p) = resp.interact_pointer_pos()
    {
        match g.hit(p) {
            Some((i, _)) => {
                if ui.input(|x| x.modifiers.shift) {
                    if !app.midi.selected.contains(&i) {
                        app.midi.selected.push(i);
                    }
                } else {
                    app.midi.selected = vec![i];
                }
                if let Some(n) = sequence.notes.get(i) {
                    app.audition_note_on(Some(track), n.pitch, n.velocity);
                    app.audition_note_off(n.pitch);
                }
            }
            None if pencil => {
                let pitch = g.pitch_at(p.y).clamp(0, 127);
                let start = g.snap_floor(g.tick_at(p.x)).max(0);
                let _ = app.run(
                    "midi.note_add",
                    json!({"clip": cid.0, "pitch": pitch, "start_ticks": start, "length_ticks": grid_ticks, "velocity": 100}),
                );
                app.audition_note_on(Some(track), pitch as u8, 100);
                app.audition_note_off(pitch as u8);
                app.midi.selected.clear();
            }
            None => app.midi.selected.clear(),
        }
    }
}

fn note_keys(app: &mut SoundApp, ui: &mut Ui, g: &Roll<'_>, cid: ClipId, playhead_tick: i64) {
    let Roll { sequence, roll, grid_ticks, .. } = *g;
    let in_midi_editor = ui.rect_contains_pointer(roll) || crate::shortcuts::piano_roll_has_pointer(app);
    if in_midi_editor && !ui.ctx().egui_wants_keyboard_input() {
        let (all, copy, paste, cut_grid, up, down, left, right, shift) = ui.input(|i| {
            let cmd = i.modifiers.command || i.modifiers.ctrl;
            let arrows = !i.modifiers.alt && !cmd;
            (
                cmd && i.key_pressed(egui::Key::A),
                cmd && i.key_pressed(egui::Key::C),
                cmd && i.key_pressed(egui::Key::V),
                !cmd && i.key_pressed(egui::Key::X),
                arrows && i.key_pressed(egui::Key::ArrowUp),
                arrows && i.key_pressed(egui::Key::ArrowDown),
                arrows && !i.modifiers.shift && i.key_pressed(egui::Key::ArrowLeft),
                arrows && !i.modifiers.shift && i.key_pressed(egui::Key::ArrowRight),
                i.modifiers.shift,
            )
        });
        if all {
            app.midi.selected = (0..sequence.notes.len()).collect();
        }
        if copy && !app.midi.selected.is_empty() {
            app.midi.clipboard = app.midi.selected.iter().filter_map(|&idx| sequence.notes.get(idx).copied()).collect();
        }
        if paste && !app.midi.clipboard.is_empty() {
    let s = app.engine.session_arc();
    let playhead_abs_tick = s.tempo.samples_to_ticks(app.position(), s.sample_rate);
    let target_base = (playhead_abs_tick - g.base_tick).max(0);
    paste_midi_clipboard(app, cid, target_base);
}
        if cut_grid {
            cut_notes_to_grid(app, cid, sequence, grid_ticks);
        }
        let semi = if up {
            1
        } else if down {
            -1
        } else {
            0
        } * if shift { 12 } else { 1 };
        let ticks = if right {
            grid_ticks
        } else if left {
            -grid_ticks
        } else {
            0
        };
        if (semi != 0 || ticks != 0) && !app.midi.selected.is_empty() {
            let moved = app.run("midi.notes_move", json!({"clip": cid.0, "indices": app.midi.selected, "ticks": ticks, "semitones": semi}));
            app.midi.selected = moved.ok().and_then(|v| serde_json::from_value(v["indices"].clone()).ok()).unwrap_or_default();
        }
    }
    if !app.midi.selected.is_empty()
        && !ui.ctx().egui_wants_keyboard_input()
        && ui.input(|i| i.key_pressed(egui::Key::Delete) || i.key_pressed(egui::Key::Backspace))
    {
        let _ = app.run("midi.note_delete", json!({"clip": cid.0, "indices": app.midi.selected}));
        app.midi.selected.clear();
    }
}

fn velocity_lane(app: &mut SoundApp, ui: &mut Ui, g: &Roll<'_>, cid: ClipId, base: Color32, label_x: f32) {
    let Roll { sequence, vel, .. } = *g;
    let t = Tokens::current();
    ui.painter().rect_filled(vel, 0.0, Color32::from_rgb(28, 28, 30));
    ui.painter().text(pos2(label_x, vel.center().y), Align2::LEFT_CENTER, crate::localization::text("Velocity"), regular(10.0), t.text_dim);
    let painter = ui.painter().with_clip_rect(vel);
    let vresp = ui.interact(vel, ui.scope_id().with(("vel", cid.0)), Sense::click_and_drag());
    for (i, n) in sequence.notes.iter().enumerate() {
        let x = g.x_of(n.start);
        if x < vel.min.x - 4.0 || x > vel.max.x + 4.0 {
            continue;
        }
        let h = (vel.height() - 4.0) * f32::from(n.velocity) / 127.0;
        let col = if app.midi.selected.contains(&i) { Color32::WHITE } else { base };
        painter.line_segment([pos2(x + 1.0, vel.max.y - 2.0), pos2(x + 1.0, vel.max.y - 2.0 - h)], Stroke::new(3.0, col));
        painter.circle_filled(pos2(x + 1.0, vel.max.y - 2.0 - h), 2.5, col);
    }
    if (vresp.clicked() || vresp.dragged())
    && let Some(p) = vresp.interact_pointer_pos()
    && let Some((i, n)) = sequence.notes.iter().enumerate().min_by_key(|(_, n)| ((g.x_of(n.start) - p.x).abs() * 10.0) as i64)
    && (g.x_of(n.start) - p.x).abs() < 8.0
{
    let v = (((vel.max.y - 2.0 - p.y) / (vel.height() - 4.0)) * 127.0).round().clamp(1.0, 127.0) as i64;
    app.midi.active_velocity = Some(v as u8);
    let _ = app.engine.execute_merged("midi.note_edit", &json!({"clip": cid.0, "index": i, "velocity": v}), &format!("vel:{}", cid.0));
} else if !vresp.dragged() && !vresp.clicked() {
    app.midi.active_velocity = None;
}
}
